from rest_framework import serializers
from .models import FreelancerProfile
class FreelancerProfileViewSerializer(serializers.ModelSerializer):
    class Meta:
        model=FreelancerProfile
        exclude = ["user_id"]